/* additional Message */
Trex.define(Trex.MESSAGE, {
	
	/* tool */
		
});


	