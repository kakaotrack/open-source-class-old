
Trex.I.Processor.StandardP = {
	
};
