## Daum Open Editor 

라이센스 : GNU LGPL(Lesser General Public License)
홈페이지 : http://code.google.com/p/daumopeneditor/

저희 다음오픈에디터의 라이선스는 GNU LGPL(Lesser General Public License) 으로
오픈되어 있는 소스이므로 저작권료 없이 사용이 가능하며, 목적에 맞게 수정하여 사용할 수 있으십니다.
또한 LGPL에는 수정한 부분의 소스공개를 권장하고 있으나, 강제 사항은 아니므로 공개하지 않으셔도 무방합니다.
다만 사용하시는 소스 상단 부분에 다음오픈에디터를 사용하셨음을 명시해 주시길 권장 드리며,
저희가 꾸준한 업데이트를 할 예정이니 
종종 방문 하셔서 버그가 수정 되고 기능이 추가된 버전들을 다운로드 받아 사용해 주세요.


지원 브라우저 : 
IE 6.0, 7.0, 8.0
Firefox 2.0, 3.0
Safari 3.0.4
Chrome 1.0.x
