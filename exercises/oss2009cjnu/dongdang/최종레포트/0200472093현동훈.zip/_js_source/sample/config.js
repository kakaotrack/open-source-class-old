
TrexConfig.add({
	pvpage: "#host#path/pages/pv/#pvname.html",
	canvas: {
	},
	events: {
		preventUnload: false
	},
	sidebar: {
		attachbox: {
			show: true
		},
		embeder: {
			media: {
			}
		},
		attacher: {
			image: {
			},
			file: {
			}
		}
	},
	plugin: {
		fullscreen: {
			use: true
		}
	}
});